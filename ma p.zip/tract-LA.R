data=read.csv("tract dataset.csv")
tract_full=subset(data,select=-c(X,X.1,X.2,X.3,X.4,X.5,X.6,X.7,X.8,X.9,X.10,X.11,X.12,X.13,X.14,X.15,X.16,X.17,X.18,X.19,X.20))
attach(tract_full)
colnames(tract_full)
tract_full=na.omit(tract_full)

###########################################################
######## maybe we can do some visualizaitions here ########
###########################################################


# Estimate the population density(residential developmen) using all variables
tract_full$poverty.rate=as.numeric(as.character(tract_full$poverty.rate))
a=lm(Residents.per.square.mile~Occupancy.rate.land.+Residential.use.land.+
       Commercial.use.land.+Industrial.use.land.+Institutional.Cultural.Civic.use.land.+
       Infrastructure.use.land.+Walk.Score+Bike.Score+Transit.Score+income+
       poverty.rate+Did.not.graduate.high.school+Graduated.high.school+
       Attained.college.degree,data=tract_full)

# Select variables
select_a=step(a)
summary(select_a)

###########################################################
######## May be we can add some interactions to each regression
###########################################################


# Estimate the income
b=lm(income~Residents.per.square.mile+Occupancy.rate.land.+Residential.use.land.+
       Commercial.use.land.+Industrial.use.land.+Institutional.Cultural.Civic.use.land.+
       Infrastructure.use.land.+Walk.Score+Bike.Score+Transit.Score+
       poverty.rate+Did.not.graduate.high.school+Graduated.high.school+
       Attained.college.degree,data=tract_full)

summary(b)
select_b=step(b)
summary(select_b)


# Estimate the commercial activities
c=lm(Commercial.use.land.~Residents.per.square.mile+Walk.Score+Bike.Score+Transit.Score+
       poverty.rate+Did.not.graduate.high.school+Graduated.high.school+
       Attained.college.degree+income,data=tract_full)

summary(c)
select_c=step(c)
summary(select_c)



# Because there is no data for other years, I do cross-validaiton here
plot(tract_full$Residents.per.square.mile,fitted.values(a))
install.packages("lattice")
library(DAAG)
val=CVlm(data=tract_full,m=5,form.lm=formula(income~Residents.per.square.mile+Occupancy.rate.land.+Residential.use.land.+
                                              Commercial.use.land.+Industrial.use.land.+Institutional.Cultural.Civic.use.land.+
                                              Infrastructure.use.land.+Walk.Score+Bike.Score+Transit.Score+
                                              poverty.rate+Did.not.graduate.high.school+Graduated.high.school+
                                              Attained.college.degree,data=tract_full))





###########################################################
# Maybe we can add a dummy: whether it is LA city center. 
# Observe the impact of this regional distribution on other variables
###########################################################